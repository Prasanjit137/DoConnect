/*
const express = require('express');
const User = require('../models/User');
const { protect, admin } = require('../middleware/authMiddleware');

const router = express.Router();

router.get('/', protect, admin, async (req, res) => {
  try {
    const questionAndAnwers = await User.find({});
    res.json(questionAndAnwers);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

router.post('/', async (req, res) => {
  const { name, email, password, role, status} = req.body;
  try {
    const userExists = await User.findOne({ email });
    if (userExists) {
      return res.status(400).json({ message: 'User already exists' });
    }

    const user = new User({ name, email, password, role,status });
    const newUser = await user.save();
    res.status(201).json(newUser);
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
});


/*
router.delete('/:id', protect, admin, async (req, res) => {
  try {
    const user = await User.findById(req.params.id);

    if (user) {
      await user.remove();
      res.json({ message: 'User removed' });
    } else {
      res.status(404).json({ message: 'User not found' });
    }
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});
*//*

router.delete('/:id', protect, admin, async (req, res) => {
  try {
    const user = await User.findByIdAndDelete(req.params.id);
    if (user) {
      res.json({ message: 'User removed' });
    } else {
      res.status(404).json({ message: 'User not found' });
    }
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
});




router.put('/:id', protect, admin, async (req, res) => {
  try {
    const user = await User.findById(req.params.id);

    if (user) {
      user.name = req.body.name || user.name;
      user.email = req.body.email || user.email;
      user.role = req.body.role || user.role;
      user.status = req.body.status || user.status;

      const updatedUser = await user.save();
      res.json(updatedUser);
    } else {
      res.status(404).json({ message: 'User not found' });
    }
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});




module.exports = router;
*/

const express = require('express');
const Answer = require('../models/Answer'); 
const Question = require('../models/Question');

const { protect, admin } = require('../middleware/authMiddleware'); 

const router = express.Router();

router.post('/:questionId', protect, async (req, res) => {
  try {
    const { text } = req.body;
    const questionId = req.params.questionId;

    const question = await Question.findById(questionId);
    if (!question) {
      return res.status(404).json({ message: 'Question not found' });
    }

    const answer = new Answer({
      text,
      user: req.user._id,
      question: questionId,
      approved: false 
    });

    await answer.save();

    res.status(201).json(answer);
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
});

router.get('/', protect, admin, async (req, res) => {
  try {
    const answers = await Answer.find().populate('user', 'name').populate('question', 'text');
    res.json(answers);
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
});

router.put('/:id/approve', protect, admin, async (req, res) => {
  try {
    const answer = await Answer.findById(req.params.id);

    if (!answer) {
      return res.status(404).json({ message: 'Answer not found' });
    }

    answer.approved = true;
    await answer.save();

    res.json(answer);
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
});


router.delete('/:id', protect, admin, async (req, res) => {
  try {
    const { id } = req.params;
    console.log(id)
    const answer = await Answer.findByIdAndDelete(id);
    
    if (answer) {
      res.json({ message: 'Answer removed' });
    } else {
      res.status(404).json({ message: 'Answer not found' });
    }
  } catch (error) {
    console.error(`Error deleting answer with ID ${req.params.id}:`, error);
    res.status(500).json({ message: 'Server error' });
  }
});



module.exports = router;
