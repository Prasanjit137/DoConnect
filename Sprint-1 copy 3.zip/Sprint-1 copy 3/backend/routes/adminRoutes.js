/*
const express = require('express');
const router = express.Router();
const { protect, admin } = require('../middleware/authMiddleware');

const { protect } = require('../middleware/authMiddleware');

router.get('/answers', protect, admin, async (req, res) => {
    try {
      const answers = await Answer.find({}).populate('user question');
      res.json(answers);
    } catch (error) {
      res.status(500).json({ message: 'Server error' });
    }
  });
*/

//router.route('/questions').get(protect, admin, getQuestions);
//router.route('/answers').get(protect, admin, getAnswers);

//export default router;