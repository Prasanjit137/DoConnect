/*
const express = require('express');
const router = express.Router();
const Answer = require('../models/Answer');
//const Question = require('../models/Question');
const { protect, admin } = require('../middleware/authMiddleware');


router.post('/', protect, async (req, res) => {
  const { question, text } = req.body;
  try {
    const answer = new Answer({
      question,
      user: req.user._id,
      text,
    });
    const newAnswer = await answer.save();
    res.status(201).json(newAnswer);
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
});


router.get('/', protect, admin, async (req, res) => {
  try {
    const answers = await Answer.find().populate('user', 'name email').populate('question');
    res.json(answers);
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
});


router.put('/:id/approve', protect, admin, async (req, res) => {
  try {
    const answer = await Answer.findById(req.params.id);
    if (answer) {
      answer.approved = true;
      const updatedAnswer = await answer.save();
      res.json(updatedAnswer);
    } else {
      res.status(404).json({ message: 'Answer not found' });
    }
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;

*/


const express = require('express');
const { protect, admin } = require('../middleware/authMiddleware');
const Answer = require('../models/Answer');

const router = express.Router();

router.post('/:questionId', protect, async (req, res) => {
  try {
    const answer = new Answer({
      text: req.body.text,
      user: req.user._id,
      question: req.params.questionId,
    });
    const createdAnswer = await answer.save();
    res.status(201).json(createdAnswer);
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
});

router.put('/:id/approve', protect, admin, async (req, res) => {
  try {
    const answer = await Answer.findById(req.params.id);
    if (answer) {
      answer.approved = true;
      await answer.save();
      res.json({ message: 'Answer approved' });
    } else {
      res.status(404).json({ message: 'Answer not found' });
    }
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
});


router.get('/', protect, async (req, res) => {
  try {
    const answers = await Answer.find().populate('user', 'name email').populate('question');
    res.json(answers);
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
});



module.exports = router;


