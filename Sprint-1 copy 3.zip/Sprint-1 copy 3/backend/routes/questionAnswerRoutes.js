import express from 'express';
import { getQuestionsAndAnswers } from '../controllers/questionController.js';
import { protect } from '../middleware/authMiddleware.js';

const router = express.Router();


router.route('/questions').get(protect, getQuestionsAndAnswers);

export default router;
