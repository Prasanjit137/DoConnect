const express = require('express');
const router = express.Router();
const Question = require('../models/Question');
const { protect, admin } = require('../middleware/authMiddleware');


router.post('/', protect, async (req, res) => {
  const { text } = req.body;
  try {
    const question = new Question({
      user: req.user._id,
      text,
    });
    const newQuestion = await question.save();
    res.status(201).json(newQuestion);
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
});


router.get('/', protect, async (req, res) => {
  try {
    const questions = await Question.find().populate('user', 'name email');
    res.json(questions);
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
});

router.delete('/:id', protect, admin, async (req, res) => {
  try {
    const question = await Question.findByIdAndDelete(req.params.id);
    if (question) {
      res.json({ message: 'Question removed' });
    } else {
      res.status(404).json({ message: 'Question not found' });
    }
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
});

router.put('/:id/approve', protect, admin, async (req, res) => {
  try {
    const question = await Question.findById(req.params.id);
    if (question) {
      question.approved = true;
      const updatedQuestion = await question.save();
      res.json(updatedQuestion);
    } else {
      res.status(404).json({ message: 'Question not found' });
    }
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;
