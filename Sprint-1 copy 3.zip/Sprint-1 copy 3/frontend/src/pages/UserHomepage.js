import React, { useState, useEffect } from 'react';
import axios from 'axios';

const UserHomepage = () => {
  const [questions, setQuestions] = useState([]);
  const [answers, setAnswers] = useState({});
  const [submittedAnswers, setSubmittedAnswers] = useState({});
  const user = JSON.parse(localStorage.getItem('user')) || { name: 'Guest', token: '' };

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [questionRes, answerRes] = await Promise.all([
          axios.get(`${process.env.REACT_APP_API_BASE_URL}/api/questions`, {
            headers: { Authorization: `Bearer ${user.token}` },
          }),
          axios.get(`${process.env.REACT_APP_API_BASE_URL}/api/answers`, {
            headers: { Authorization: `Bearer ${user.token}` },
          }),
        ]);

        setQuestions(questionRes.data.filter(q => q.approved));
        const answersByQuestionId = answerRes.data.reduce((acc, answer) => {
          if (answer.approved) {
            acc[answer.question._id] = acc[answer.question._id] || [];
            acc[answer.question._id].push(answer);
          }
          return acc;
        }, {});
        setSubmittedAnswers(answersByQuestionId);
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };

    fetchData();
  }, [user]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setAnswers(prevAnswers => ({ ...prevAnswers, [name]: value }));
  };

  const handleSubmitAnswer = async (questionId) => {
    try {
      await axios.post(`${process.env.REACT_APP_API_BASE_URL}/api/answers/${questionId}`, {
        text: answers[questionId],
      }, {
        headers: { Authorization: `Bearer ${user.token}` },
      });

      setAnswers(prevAnswers => ({ ...prevAnswers, [questionId]: '' }));
      handleFetchAnswers();
    } catch (error) {
      console.error('Error submitting answer:', error);
    }
  };

  const handlePostQuestion = async (e) => {
    e.preventDefault();
    try {
      await axios.post(`${process.env.REACT_APP_API_BASE_URL}/api/questions`, { text: answers.questionText }, {
        headers: { Authorization: `Bearer ${user.token}` },
      });

      setAnswers(prevAnswers => ({ ...prevAnswers, questionText: '' }));
      handleFetchQuestions();
    } catch (error) {
      console.error('Error posting question:', error);
    }
  };

  const handleFetchAnswers = async () => {
    try {
      const answerRes = await axios.get(`${process.env.REACT_APP_API_BASE_URL}/api/answers`, {
        headers: { Authorization: `Bearer ${user.token}` },
      });
      const answersByQuestionId = answerRes.data.reduce((acc, answer) => {
        if (answer.approved) {
          acc[answer.question._id] = acc[answer.question._id] || [];
          acc[answer.question._id].push(answer);
        }
        return acc;
      }, {});
      setSubmittedAnswers(answersByQuestionId);
    } catch (error) {
      console.error('Error fetching answers:', error);
    }
  };

  const handleFetchQuestions = async () => {
    try {
      const { data } = await axios.get(`${process.env.REACT_APP_API_BASE_URL}/api/questions`, {
        headers: { Authorization: `Bearer ${user.token}` },
      });
      setQuestions(data.filter(q => q.approved));
    } catch (error) {
      console.error('Error fetching questions:', error);
    }
  };

  return (
    <div className="container">
      <h1 className="text-center my-4">Welcome, {user.name || 'User'}</h1>

      <form className="mb-4" onSubmit={handlePostQuestion}>
        <div className="mb-3">
          <label className="form-label fw-bold">Post a new question</label>
          <textarea
            className="form-control"
            name="questionText"
            rows="3"
            value={answers.questionText || ''}
            onChange={handleChange}
            required
          />
        </div>
        <button className="btn btn-primary" type="submit">Submit</button>
      </form>

      <h2>Questions</h2>
      <ul className="list-group mb-4">
        {questions.length > 0 ? (
          questions.map(q => (
            <li className="list-group-item" key={q._id}>
              <p>{q.text}</p>
              <ul className="list-unstyled">
                {submittedAnswers[q._id] && submittedAnswers[q._id].map(a => (
                  <li key={a._id}>{a.text}</li>
                ))}
              </ul>
              <textarea
                className="form-control mb-2"
                placeholder="Submit answer"
                value={answers[q._id] || ''}
                onChange={(e) => handleChange({ target: { name: q._id, value: e.target.value } })}
              />
              <button className="btn btn-outline-primary" onClick={() => handleSubmitAnswer(q._id)}>Submit Answer</button>
            </li>
          ))
        ) : (
          <p>No questions available.</p>
        )}
      </ul>

      <h2>Submitted Answers</h2>
      <table className="table table-striped">
        <thead>
          <tr>
            <th>User</th>
            <th>Question</th>
            <th>Answer</th>
          </tr>
        </thead>
<tbody>
  {Object.keys(submittedAnswers).length > 0 ? (
    Object.keys(submittedAnswers).map(questionId => {
      
      return submittedAnswers[questionId].map(a => {
        //console.log(questionId, user.name)
        return (
          <tr key={a._id}>
            <td>{questionId ? user.name : 'Unknown User'}</td>
            <td>{questions.find(q => q._id === a.question._id)?.text || 'No Question'}</td>
            <td>{a.text}</td>
          </tr>
        );
      });
    })
  ) : (
    <tr><td colSpan="3">No answers available.</td></tr>
  )}
</tbody>
      </table>
    </div>
  );
};

export default UserHomepage;
