import React, { useState, useContext } from 'react';
import { AuthContext } from '../context/AuthContext';
import { useNavigate } from 'react-router-dom';

const Register = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState('user');
  const { register } = useContext(AuthContext);
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await register(name, email, password, role);
      navigate('/');
    } catch (error) {
      console.error('Registration failed:', error);
    }
  };

  return (
    <div>

<div className="container mt-4">
            <h2>Register</h2>

            <form onSubmit={handleSubmit} className="border border-dark p-5 rounded">

                <div className="mb-3">
                    <label htmlFor="name" className="form-label">Name</label>
                    <input
                        id="name"
                        name="name"
                        type="text" 
                        className="form-control"
                        value={name} onChange={(e) => setName(e.target.value)}
                        required 
                    />
                </div>

                <div className="mb-3">
                    <label htmlFor="email" className="form-label">Email</label>
                    <input
                        id="email"
                        name="email"
                        type="email" 
                        className="form-control"
                        value={email} onChange={(e) => setEmail(e.target.value)} 
                        required 
                    />
                </div>



                <div className="mb-3">
                    <label htmlFor="password" className="form-label">Password</label>
                    <input
                        id="password"
                        name="password"
                        type="password"
                        className="form-control"
                        value={password} onChange={(e) => setPassword(e.target.value)} 
                        required 
                    />
                </div>


                <div className="mb-3">
                    <label htmlFor="role" className="form-label">Role</label>
                    <select
                        id="role"
                        name="role"
                        className="form-control"
                        value={role} onChange={(e) => setRole(e.target.value)}
                        required >

                            <option value="user">User</option>
                            <option value="admin">Admin</option>

                    </select>
                </div>


                <button type="submit" className="btn btn-primary">
                    Submit
                </button>
            </form>
        </div>
    </div>
  );
};

export default Register;
