import React, { useContext } from 'react';
import { AuthContext } from '../context/AuthContext';
import AdminDashboard from './AdminDashboard';
import Questions from './Questions';
import UserHomepage from './UserHomepage';
const Home = () => {
  const { user } = useContext(AuthContext);

  return (
    <div>
      {user ? (
        (user.role === 'admin') ? (
          <AdminDashboard />
      ):(
        <UserHomepage/>
      )   
      ) : (
        <h2>Welcome to Do Connect!</h2>
      )}
    </div>
  );
};

export default Home;
