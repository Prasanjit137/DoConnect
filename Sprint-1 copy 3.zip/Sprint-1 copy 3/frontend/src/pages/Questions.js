import React, { useState, useEffect, useContext } from 'react';
import axios from 'axios';
import { AuthContext } from '../context/AuthContext';

const UserHomepage = () => {
  //const { user } = useContext(AuthContext);
  const [answers, setAnswers] = useState({});
  const [question, setQuestion] = useState('');
  const [questions, setQuestions] = useState([]);
  const [user, setUser] = useState(JSON.parse(localStorage.getItem('user')));

  useEffect(() => {
    const fetchQuestions = async () => {
      try {
        const { data } = await axios.get(`${process.env.REACT_APP_API_BASE_URL}/api/questions`, {
          headers: {
            Authorization: `Bearer ${user.token}`,
          },
        });
        setQuestions(data.filter(q => q.approved));
      } catch (error) {
        console.error('Error fetching questions:', error);
      }
    };

    fetchQuestions();
  }, [user]);

  const handleQuestionChange = (e) => {
    setQuestion(e.target.value);
  };

  const handleSubmitQuestion = async (e) => {
    e.preventDefault();
    try {
      await axios.post(`${process.env.REACT_APP_API_BASE_URL}/api/questions`, { text: question }, {
        headers: {
          Authorization: `Bearer ${user.token}`,
        },
      });
      setQuestion('');
      const { data } = await axios.get(`${process.env.REACT_APP_API_BASE_URL}/api/questions`, {
        headers: {
          Authorization: `Bearer ${user.token}`,
        },
      });
      setQuestions(data.filter(q => q.approved));
    } catch (error) {
      console.error('Error posting question:', error);
    }
  };

  useEffect(() => {
    const fetchQuestionsAndAnswers = async () => {
      try {
        const { data: approvedQuestions } = await axios.get(`${process.env.REACT_APP_API_BASE_URL}/api/questions`, {
          headers: {
            Authorization: `Bearer ${user.token}`,
          },
        });
        setQuestions(approvedQuestions);

        const answersForQuestions = {};
        for (const question of approvedQuestions) {
          const { data: approvedAnswers } = await axios.get(`${process.env.REACT_APP_API_BASE_URL}/api/answers/${question._id}`, {
            headers: {
              Authorization: `Bearer ${user.token}`,
            },
          });
          answersForQuestions[question._id] = approvedAnswers
            .filter(answer => answer.approved)
            .map(answer => ({ id: answer._id, text: answer.text }));
        }

        setAnswers(answersForQuestions);
      } catch (error) {
        console.error('Error fetching questions or answers:', error);
      }
    };

    fetchQuestionsAndAnswers();
  }, [user]);

  const handleSubmitAnswer = async (questionId) => {
    try {
      await axios.post(`${process.env.REACT_APP_API_BASE_URL}/api/answers/${questionId}`, {
        text: answers[questionId] || '',
      }, {
        headers: {
          Authorization: `Bearer ${user.token}`,
        },
      });
      setAnswers({ ...answers, [questionId]: '' });
    } catch (error) {
      console.error('Error submitting answer:', error);
    }
  };

  return (
    <div>

      <div>
      {user && (
       <div class="container">
       <div class="row justify-content-center">
           <form class="col-md-8" onSubmit={handleSubmitQuestion}>
               <div class="mb-3">
                    <label for="exampleFormControlTextarea1" class="form-label fw-bold">Post a new question</label>
                   <textarea class="form-control mb-3" id="exampleFormControlTextarea1" rows="3" type="text" value={question} onChange={handleQuestionChange} required></textarea>
                   <div class="text-end">
                       <button class="btn btn-outline-primary" type="submit">Submit</button>
                   </div>
               </div>
            </form>
        </div>
        </div>
   
    
      )}
    </div>
    <div>
      <h1>Welcome, {user.name}</h1>
      <h2>Questions</h2>
      
      <ul>
        {questions.map((q) => (
          <li key={q._id}>
            <p>{q.text}</p>
            <ul>
              {answers[q._id] && answers[q._id].length > 0 ? (
                answers[q._id].map((a) => (
                  <li key={a.id}>{a.text}</li>
                ))
              ) : (
                <li>No approved answers yet.</li>
              )}
            </ul>
            <textarea
              value={answers[q._id] || ''}
              onChange={(e) => setAnswers({ ...answers, [q._id]: e.target.value })}
              placeholder="Submit answer"
            />
            <button onClick={() => handleSubmitAnswer(q._id)}>Submit Answer</button>
          </li>
        ))}
      </ul>
    </div>



<div class="container mt-5">

        <div class="mb-3">
        <h2>Questions</h2>
        
            <h4>Question 1: What is the capital of France?</h4>
            <button class="btn btn-primary" type="button" data-bs-toggle="collapse" data-bs-target="#answer1" aria-expanded="false" aria-controls="answer1">
                Answer this question
            </button>
            <div class="collapse mt-3" id="answer1">
                <div class="card card-body">
                    <input type="text" class="form-control mb-3" placeholder="Write your answer here"></input>
                    <button class="btn btn-success">Submit Answer</button>
                </div>
            </div>
        </div>
    </div>


    <div>

      <h2>Your Questions</h2>
      {questions.length > 0 ? (
        <ul>
          {questions.map(q => (
            <li key={q._id}>{q.text}</li>
          ))}
        </ul>
      ) : (
        <p>No questions available</p>
      )}
    </div>

    </div>
  );
};

export default UserHomepage;
