

import React, { useEffect, useState, useContext } from 'react';
import axios from 'axios';
import { AuthContext } from '../context/AuthContext';

const AdminDashboard = () => {
  const { user } = useContext(AuthContext);
  const [questions, setQuestions] = useState([]);
  const [answers, setAnswers] = useState([]);
  const [users, setUsers] = useState([]);
  const [editUser, setEditUser] = useState(null);
  const [newUser, setNewUser] = useState({ name: '', email: '', password: '', role: 'user', status: 'active' });
  const [questionText, setQuestionText] = useState('');

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [questionsRes, answersRes, usersRes] = await Promise.all([
          axios.get(`${process.env.REACT_APP_API_BASE_URL}/api/questions`, {
            headers: { Authorization: `Bearer ${user.token}` },
          }),
          axios.get(`${process.env.REACT_APP_API_BASE_URL}/api/answers`, {
            headers: { Authorization: `Bearer ${user.token}` },
          }),
          axios.get(`${process.env.REACT_APP_API_BASE_URL}/api/users`, {
            headers: { Authorization: `Bearer ${user.token}` },
          }),
        ]);

        setQuestions(questionsRes.data);
        setAnswers(answersRes.data);
        setUsers(usersRes.data);
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };

    fetchData();
  }, [user]);

  const handlePostQuestion = async (e) => {
    e.preventDefault();
    try {
      await axios.post(`${process.env.REACT_APP_API_BASE_URL}/api/questions`, { text: questionText }, {
        headers: { Authorization: `Bearer ${user.token}` },
      });

      setQuestionText('');
      const { data } = await axios.get(`${process.env.REACT_APP_API_BASE_URL}/api/questions`, {
        headers: { Authorization: `Bearer ${user.token}` },
      });
      setQuestions(data);
    } catch (error) {
      console.error('Error posting question:', error);
    }
  };

  const handleApproveQuestion = async (id) => {
    try {
      await axios.put(`${process.env.REACT_APP_API_BASE_URL}/api/questions/${id}/approve`, {}, {
        headers: { Authorization: `Bearer ${user.token}` },
      });
      setQuestions(questions.map(q => q._id === id ? { ...q, approved: true } : q));
    } catch (error) {
      console.error('Error approving question:', error);
    }
  };

  const deleteQuestion = async (id) => {
    try {
      await axios.delete(`${process.env.REACT_APP_API_BASE_URL}/api/questions/${id}`, {
        headers: { Authorization: `Bearer ${user.token}` },
      });
      setQuestions(questions.filter(q => q._id !== id));
    } catch (error) {
      console.error('Error deleting user:', error);
    }
  };

  const handleApproveAnswer = async (id) => {
    try {
      await axios.put(`${process.env.REACT_APP_API_BASE_URL}/api/answers/${id}/approve`, {}, {
        headers: { Authorization: `Bearer ${user.token}` },
      });
      const { data } = await axios.get(`${process.env.REACT_APP_API_BASE_URL}/api/answers`, {
        headers: { Authorization: `Bearer ${user.token}` },
      });
      setAnswers(data);
    } catch (error) {
      console.error('Error approving answer:', error);
    }
  };

  const deleteAnswer = async (id) => {
    try {
      await axios.delete(`${process.env.REACT_APP_API_BASE_URL}/api/answers/${id}`, {
        headers: { Authorization: `Bearer ${user.token}` },
      });
      setAnswers(questions.filter(a => a._id !== id));
    } catch (error) {
      console.error('Error deleting user:', error);
    }
  };

  const handleEditChange = (e) => {
    setEditUser({ ...editUser, [e.target.name]: e.target.value });
  };

  const handleNewUserChange = (e) => {
    setNewUser({ ...newUser, [e.target.name]: e.target.value });
  };

  const updateUser = async (id) => {
    try {
      const { data } = await axios.put(`${process.env.REACT_APP_API_BASE_URL}/api/users/${id}`, editUser, {
        headers: { Authorization: `Bearer ${user.token}` },
      });
      setUsers(users.map(u => u._id === id ? data : u));
      setEditUser(null);
    } catch (error) {
      console.error('Error updating user:', error);
    }
  };

  const addUser = async () => {
    try {
      const { data } = await axios.post(`${process.env.REACT_APP_API_BASE_URL}/api/users`, newUser, {
        headers: { Authorization: `Bearer ${user.token}` },
      });
      setUsers([...users, data]);
      setNewUser({ name: '', email: '', password: '', role: 'user', status: 'active' });
    } catch (error) {
      console.error('Error adding user:', error);
    }
  };

  const deleteUser = async (id) => {
    try {
      await axios.delete(`${process.env.REACT_APP_API_BASE_URL}/api/users/${id}`, {
        headers: { Authorization: `Bearer ${user.token}` },
      });
      setUsers(users.filter(user => user._id !== id));
    } catch (error) {
      console.error('Error deleting user:', error);
    }
  };

  return (
    <div className="container mt-4">

<h1>Admin Dashboard</h1>

<section className="mb-5">
  <h2>Add New User</h2>
  <div className="container">
    <div className="row justify-content-center">
      <form className="col-md-6" onSubmit={(e) => { e.preventDefault(); addUser(); }}>
        <div className="form-group">
          <label htmlFor="name">Name:</label>
          <input
            type="text"
            className="form-control"
            id="name"
            name="name"
            value={newUser.name}
            onChange={handleNewUserChange}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="email">Email:</label>
          <input
            type="email"
            className="form-control"
            id="email"
            name="email"
            value={newUser.email}
            onChange={handleNewUserChange}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="password">Password:</label>
          <input
            type="password"
            className="form-control"
            id="password"
            name="password"
            value={newUser.password}
            onChange={handleNewUserChange}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="role">Role:</label>
          <select
            className="form-control"
            id="role"
            name="role"
            value={newUser.role}
            onChange={handleNewUserChange}
          >
            <option value="user">User</option>
            <option value="admin">Admin</option>
          </select>
        </div>
        <div className="form-group">
          <label htmlFor="status">Status:</label>
          <select
            className="form-control"
            id="status"
            name="status"
            value={newUser.status}
            onChange={handleNewUserChange}
          >
            <option value="active">Active</option>
            <option value="inactive">Inactive</option>
          </select>
        </div>
        <button type="submit" className="btn btn-primary">Add User</button>
      </form>
    </div>
  </div>
</section>

<section className="mb-5">
  <h2>User List</h2>
  <div className="table-responsive mt-3">
    <table className="table table-striped table-bordered">
      <thead className="thead-dark">
        <tr>
          <th>Name</th>
          <th>Email</th>
          <th>Role</th>
          <th>Status</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        {users.map((user) => (
          <tr key={user._id}>
            <td>{editUser?._id === user._id ? (
              <input
                type="text"
                name="name"
                value={editUser.name}
                onChange={handleEditChange}
                className="form-control"
              />
            ) : (
              user.name
            )}</td>
            <td>{editUser?._id === user._id ? (
              <input
                type="email"
                name="email"
                value={editUser.email}
                onChange={handleEditChange}
                className="form-control"
              />
            ) : (
              user.email
            )}</td>
            <td>{editUser?._id === user._id ? (
              <select
                name="role"
                value={editUser.role}
                onChange={handleEditChange}
                className="form-control"
              >
                <option value="user">User</option>
                <option value="admin">Admin</option>
              </select>
            ) : (
              user.role
            )}</td>
            <td>{editUser?._id === user._id ? (
              <select
                name="status"
                value={editUser.status}
                onChange={handleEditChange}
                className="form-control"
              >
                <option value="active">Active</option>
                <option value="inactive">Inactive</option>
              </select>
            ) : (
              user.status
            )}</td>
            <td>
              {editUser?._id === user._id ? (
                <>
                  <button
                    className="btn btn-success mr-2"
                    onClick={() => updateUser(user._id)}
                  >
                    Save
                  </button>
                  <button
                    className="btn btn-secondary"
                    onClick={() => setEditUser(null)}
                  >
                    Cancel
                  </button>
                </>
              ) : (
                <>
                  <button
                    className="btn btn-warning mr-2 me-2"
                    onClick={() => setEditUser(user)}
                  >
                    Edit
                  </button>
                  <button
                    className="btn btn-danger"
                    onClick={() => deleteUser(user._id)}
                  >
                    Delete
                  </button>
                </>
              )}
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  </div>
</section>





      <section className="mb-5">
        <h2>Post a Question</h2>
        <form onSubmit={handlePostQuestion}>
          <div className="form-group">
            <label htmlFor="questionText">Question:</label>
            <input
              type="text"
              className="form-control"
              id="questionText"
              value={questionText}
              onChange={(e) => setQuestionText(e.target.value)}
              required
            />
          </div>
          <button type="submit" className="btn btn-primary">Post Question</button>
        </form>
      </section>



      <section className="mb-5">
        <h2 className="mb-4">Questions & Answers</h2>
        <ul className="nav nav-tabs" id="myTab" role="tablist">
          <li className="nav-item" role="presentation">
            <a className="nav-link active" id="nav-questions-tab" data-bs-toggle="tab" href="#nav-questions" role="tab" aria-controls="nav-questions" aria-selected="true">
              Questions
            </a>
          </li>
          <li className="nav-item" role="presentation">
            <a className="nav-link" id="nav-answers-tab" data-bs-toggle="tab" href="#nav-answers" role="tab" aria-controls="nav-answers" aria-selected="false">
              Answers
            </a>
          </li>
        </ul>
        <div className="tab-content mt-3" id="myTabContent">

          <div className="tab-pane fade show active" id="nav-questions" role="tabpanel" aria-labelledby="nav-questions-tab">
            <div className="table-responsive mt-3">
              <table className="table table-striped table-bordered">
                <thead className="thead-dark">
                  <tr>
                    <th>Question</th>
                    <th>Approved</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {questions.map((question) => (
                    <tr key={question._id}>
                      <td>{question.text}</td>
                      <td>{question.approved ? 'Yes' : 'No'}</td>
                      <td>
                        {!question.approved && (
                          <button
                            className="btn btn-primary me-2"
                            onClick={() => handleApproveQuestion(question._id)}
                          >
                            Approve
                          </button>
                        )}

                        {!question.approved && (
                          <button
                            className="btn btn-danger me-2"
                            onClick={() => deleteQuestion(question._id)}
                          >
                            Delete
                          </button>
                        )}

   
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>








              <table className="table table-striped table-bordered">
      <thead className="thead-dark">
        <tr>
          <th>Question</th>
          <th>Approved</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
          {questions.map((question) => (
           <tr key={question._id}>
            <td>{editUser?._id === user._id ? (
              <input
                type="text"
                name="name"
                value={editUser.name}
                onChange={handleEditChange}
                className="form-control"
              />
            ) : (
              user.name
            )}</td>
            <td>{editUser?._id === user._id ? (
              <input
                type="email"
                name="email"
                value={editUser.email}
                onChange={handleEditChange}
                className="form-control"
              />
            ) : (
              user.email
            )}</td>
            <td>{editUser?._id === user._id ? (
              <select
                name="role"
                value={editUser.role}
                onChange={handleEditChange}
                className="form-control"
              >
                <option value="user">User</option>
                <option value="admin">Admin</option>
              </select>
            ) : (
              user.role
            )}</td>
            <td>{editUser?._id === user._id ? (
              <select
                name="status"
                value={editUser.status}
                onChange={handleEditChange}
                className="form-control"
              >
                <option value="active">Active</option>
                <option value="inactive">Inactive</option>
              </select>
            ) : (
              user.status
            )}</td>
            <td>
              {editUser?._id === user._id ? (
                <>
                  <button
                    className="btn btn-success mr-2"
                    onClick={() => updateUser(user._id)}
                  >
                    Save
                  </button>
                  <button
                    className="btn btn-secondary"
                    onClick={() => setEditUser(null)}
                  >
                    Cancel
                  </button>
                </>
              ) : (
                <>
                  <button
                    className="btn btn-warning mr-2 me-2"
                    onClick={() => setEditUser(user)}
                  >
                    Edit
                  </button>
                  <button
                    className="btn btn-danger"
                    onClick={() => deleteUser(user._id)}
                  >
                    Delete
                  </button>
                </>
              )}
            </td>
          </tr>
        ))}
      </tbody>
    </table>







    
            </div>
          </div>

          <div className="tab-pane fade" id="nav-answers" role="tabpanel" aria-labelledby="nav-answers-tab">
            <div className="table-responsive mt-3">
              <table className="table table-striped table-bordered">
                <thead className="thead-dark">
                  <tr>
                    <th>Question</th>
                    <th>Answer Text</th>
                    <th>Approved</th>
                    <th>Actions</th>
                    
                  </tr>
                </thead>
                <tbody>
                  {answers.map((answer) => {
                    
                    //console.log('Answer:', answer);
                    //const question = questions.find(q => q._id === answer.question);
                    
                    //console.log('Matching Question:', question);
                    
                    //if(answer.question._id == questions.map((question) => (question._id))){
                   /* 
                    if(true){
                      //console.log(answer.question._id)
                      //console.log(questions.map((question) => (question._id)))
                      return(
                        <h3>{questions.map((question) => (question._id))}
                        <br></br>
                        {answer.question._id}
                        </h3>
                      );
                  }*/
                    //console.log(answer.question._id)
                    
                    return (
                      <tr key={answer._id}>
                        <td>{answer._id ? answer.question.text : 'Unknown Question'}</td>
                        <td>{answer.text}</td>
                        <td>{answer.approved ? 'Yes' : 'No'}</td>
                        <td>
                          
                          {!answer.approved && (
                            <button
                              className="btn btn-primary"
                              onClick={() => handleApproveAnswer(answer._id)}
                            >
                              Approve
                            </button>
                          )}
                          {!answer.approved && (
                            <button
                              className="btn btn-danger"
                              onClick={() => deleteAnswer(answer._id)}
                            >
                              Delete
                            </button>
                          )}
                          
                        </td>
                        
                      </tr>
                    );

                    
                    //}
                  })}
                </tbody>
              </table>
              
            </div>


            
          </div>
        </div>
      </section>

      
      
    </div>
  );
};

export default AdminDashboard;
