import React, { useContext } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { AuthContext } from '../context/AuthContext';

const Navbar = () => {
  const { user, logout } = useContext(AuthContext);
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <div>
      <nav class="navbar bg-body-tertiary">
  <div class="container-fluid">
  <a class="navbar-brand">Do Connect</a>

  <div class="navbar-nav">
            <Link class="nav-link active" to="/">Home</Link>
    </div>

    <div class="d-flex">
    {!user && (
              <>
                <Link class="btn btn-outline-success me-2" to="/register">Register</Link>
                <Link class="btn btn-outline-primary" to="/login">Login</Link>

              </>
            )}
            {user && (
              <>
                <Link class="btn btn-outline-primary" onClick={handleLogout}>Logout</Link>
              </>
            )}
    </div>
  </div>
</nav>
    </div>
  );
};

export default Navbar;
